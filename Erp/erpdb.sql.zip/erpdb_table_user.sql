
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `groups` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `email`, `groups`) VALUES
(1, 'customer', 'pass', 'customer@gmail.com', 1),
(2, 'shop', 'pass', 'shop@gmail.com', 2),
(5, 'admin', 'pass', 'admin@gmail.com', 3);
