
-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE `shop` (
  `shop_id` int(11) NOT NULL,
  `reg_no` int(11) NOT NULL,
  `shop_name` varchar(100) NOT NULL,
  `shop_owner` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `picture` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
